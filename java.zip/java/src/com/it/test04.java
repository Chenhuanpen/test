package com.it;

import java.math.BigDecimal;
import java.util.Scanner;

public class test04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你购买的苹果斤数：");
        int apple = scanner.nextInt();
        System.out.println("请输入你购买的草莓斤数：");
        int strawberry = scanner.nextInt();
        System.out.println("请输入你购买的芒果斤数：");
        int mango = scanner.nextInt();
        double price = apple*8+strawberry*13*0.8+mango*20;
        Double dicount = Double.valueOf(10);
        double num= Double.valueOf(0);
        if(price>=100){
            //精度丢失解决
            BigDecimal b1 = new BigDecimal(Double.toString(price));
            BigDecimal b2 = new BigDecimal(Double.toString(dicount));
            num = b1.subtract(b2).doubleValue();
        }
        System.out.println("商品的总价为："+num);
    }
}
