package com.it;

import java.util.Scanner;

public class test03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你购买的苹果斤数：");
        int apple = scanner.nextInt();
        System.out.println("请输入你购买的草莓斤数：");
        int strawberry = scanner.nextInt();
        System.out.println("请输入你购买的芒果斤数：");
        int mango = scanner.nextInt();
        double price = apple*8+strawberry*13*0.8+mango*20;
        System.out.println("商品的总价为："+price);
    }
}
