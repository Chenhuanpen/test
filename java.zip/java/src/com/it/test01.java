package com.it;

import java.util.Scanner;

public class test01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你购买的苹果斤数：");
        int apple = scanner.nextInt();
        System.out.println("请输入你购买的草莓斤数：");
        int strawberry = scanner.nextInt();
        int price = apple*8+strawberry*13;
        System.out.println("商品的总价为："+price);
    }
}
